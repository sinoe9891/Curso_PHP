<?php 

$texto = 'Hola Carlos';

// echo htmlspecialchars($texto);
// echo trim($texto);
// echo strlen($texto);
// echo substr($texto, 0, 4);

// echo strtoupper($texto);
// echo strtolower($texto);

echo strpos($texto, 'o');

?>