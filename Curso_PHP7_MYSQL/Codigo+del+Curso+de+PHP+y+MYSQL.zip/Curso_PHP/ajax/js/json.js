// var nombre = 'Carlos';
// var edad = 23;
// var pais = 'Mexico';

// var nombre2 = 'Alejandro';
// var edad2 = 30;
// var pais2 = 'España';

// Ejemplo de un Objeto
var carlos = {
	"nombre": "Carlos Arturo",
	"edad": 23,
	"pais": "Mexico"
}

var alejandro = {
	"nombre": "Alejandro",
	"edad": 30,
	"pais": "España"
}

// Ejemplo de Arreglo
var nombreAmigos = ['Alejandro', 'Manuel'];

// Ejemplo de JSON
var amigos = [
	{
		"nombre": "Alejandro",
		"edad": 24,
		"pais": "España"
	},
	{
		"nombre": "Manuel",
		"edad": 30,
		"pais": "Colombia"
	}
];

console.log(amigos[0].pais);