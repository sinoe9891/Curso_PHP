<?php

$x = 20;

while($x >= 1){
	echo $x . '<br>';

	$x--;
}

?>