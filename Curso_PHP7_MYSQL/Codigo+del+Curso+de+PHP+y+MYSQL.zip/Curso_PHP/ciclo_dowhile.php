<?php 

$i = 1;

do {
	echo $i . '<br />';
	$i++;
} while($i <= 20);

?>