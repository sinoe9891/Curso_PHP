<?php 

// echo nos sirve para mostrar informacion en pantalla
// echo "Hola Mundo";

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<h1><?php echo "Hola Mundo"; ?></h1>
</body>
</html>