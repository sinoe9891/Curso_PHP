<?php
declare(strict_types=1);
function obtenerEdad() : int{
	$edad = '23';
	return $edad;
}

echo obtenerEdad();