<?php

for($i = 0 ; $i <= 100 ; $i = $i + 5 ){
	echo $i . "<br />";
}

?>