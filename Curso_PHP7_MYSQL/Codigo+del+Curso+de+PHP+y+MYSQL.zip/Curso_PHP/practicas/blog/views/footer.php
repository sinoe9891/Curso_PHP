<footer>
	<p class="copyright">Copyright © 2015 - 2016 Carlos Arturo</p>
</footer>

</body>
</html>