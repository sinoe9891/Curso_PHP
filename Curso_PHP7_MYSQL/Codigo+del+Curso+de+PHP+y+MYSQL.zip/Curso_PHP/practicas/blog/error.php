<?php require 'admin/config.php'; ?>
<?php require 'views/header.php'; ?>

<div class="contenedor">
	<div class="post">
		<article>
			<h2 class="titulo">Error</h2>
			<br>
			<p class="extracto">Error de conexion</p>
		</article>
	</div>
</div>

<?php require 'views/footer.php'; ?>