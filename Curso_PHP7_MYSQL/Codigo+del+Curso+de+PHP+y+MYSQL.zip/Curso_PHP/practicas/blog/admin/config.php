<?php

define('RUTA', 'http://localhost/cursos/Curso_PHP/practicas/blog/');


$bd_config = array(
	'basedatos' => 'curso_blog',
	'usuario' => 'root',
	'pass' => ''
);

$blog_config = array(
	'post_por_pagina'=> '2',
	'carpeta_imagenes' => 'imagenes/'
);

$blog_admin = array(
	'usuario' => 'Carlos',
	'password' => '123'
);

?>