<?php 

$mes = 'Enero';
$verdadero = true;

// if ($verdadero) {
// 	echo "Verdadero";
// } else {
// 	echo "Falso";
// }

if ($mes == 'Diciembre') {
	echo "Feliz Navidad";
} else if($mes == 'Enero'){
	echo "Feliz Año Nuevo";
} else if ($mes == 'Julio'){
	echo "Feliz Julio";
} else {
	echo "El mes que pusiste no tiene celebracion";
}


 ?>