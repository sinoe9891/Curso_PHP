<?php 

$texto = 'Carlos';
$numero = 10;
$numero2 = '5';
$arreglo = array('Carlos', 'Cesar', 'Alejandro');
$arreglo_asosiativo = array('nombre' => 'Carlos', 'edad' => 20);
$boleano = false;

print_r($boleano);

?>